﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace BSG
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool tekrarEdilebilirMi = true;
        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }
        ArrayList kullanilabilecekKarakterler = new ArrayList();
        ArrayList tekrar = new ArrayList();
        ArrayList olusanSifreler = new ArrayList();
        string denekKelime;
        Random rnd = new Random();
        public long TekrarsızPermutasyon(byte karakterler,byte istenenSayi) {
            if (istenenSayi > karakterler)
            {
                MessageBox.Show("Kombinasyon için karakter sayısının İstenen sayıdan az olmaması gerekir.");
                
            }
            long bFak = 1;
            long aFak = 1;
            for (byte i = 1; i <= karakterler; i++){ aFak *= i; }
            if (karakterler == istenenSayi)
            {
                return aFak;
            }
            else
            {
                for (byte i = 1; i <= (karakterler - istenenSayi); i++) { bFak *= i; }
                return aFak/bFak;
            }
        }
        public long tekrarlıPermutasyon(long karakterler,byte istenenSayi) {
            byte temp = (byte)karakterler;
            for (byte i = 1; i < istenenSayi; i++)
            { 
                karakterler *= temp;
            }
            return karakterler; 
        }
        private void SifrelemeBaslat_Click(object sender, EventArgs e)
        {
            if (listKullanilabilecek.Items.Count > 0)
            {
                try
                {
                    File.WriteAllText(Application.StartupPath + "\\ BSG Olusturulan Sifreler.txt", string.Empty);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                    throw;
                }
                if (tekrarEdilebilirMi)
                {
                    for (int i = 0; i < TekrarsızPermutasyon(Convert.ToByte(listKullanilabilecek.Items.Count), Convert.ToByte(comboBox1.SelectedIndex + 1)); i++)
                    {
                    tekrarEdilemez:
                        denekKelime = "";
                    for (int a = 0; a < kullanilabilecekKarakterler.Count; a++)
                    {
                        if (!tekrar.Contains(kullanilabilecekKarakterler[a]))
                        {
                            tekrar.Add(kullanilabilecekKarakterler[a]);
                        }
                    }
                    // dizi yedeği alınıyor.
                    for (byte j = 0; j < (Convert.ToByte(comboBox1.SelectedItem.ToString())); j++)
                    {
                        int random = rnd.Next(tekrar.Count);
                        denekKelime += tekrar[random].ToString();
                        tekrar.RemoveAt(random);
                    }
                    if (olusanSifreler.Contains(denekKelime))
                    {
                        goto tekrarEdilemez;
                    }
                    else
                    {
                        olusanSifreler.Add(denekKelime);
                    }
                }
                for (int i = 0; i < olusanSifreler.Count; i++)
                {
                    lstDeneme.Items.Add(olusanSifreler[i]);
                    
                }
                    lstDeneme.Items.Add("\n");
                }
                else
                {
                    for (int i = 0; i < tekrarlıPermutasyon(listKullanilabilecek.Items.Count,Convert.ToByte(comboBox1.SelectedItem.ToString())); i++)
                    {
                    tekrarEdilebilir:
                        denekKelime = "";
                        for (int a = 0; a < kullanilabilecekKarakterler.Count; a++)
                        {
                            if (!tekrar.Contains(kullanilabilecekKarakterler[a]))
                            {
                                tekrar.Add(kullanilabilecekKarakterler[a]);
                            }
                        }
                        for (int j = 0; j < Convert.ToInt32(comboBox1.SelectedItem.ToString()); j++)
                        {
                            int random = rnd.Next(tekrar.Count);
                            denekKelime += tekrar[random].ToString();
                        }
                        if (olusanSifreler.Contains(denekKelime))
                        {
                            goto tekrarEdilebilir;
                        }
                        else
                        {
                            olusanSifreler.Add(denekKelime);
                        }
                    }
                    foreach (var item in olusanSifreler)
                    {
                        lstDeneme.Items.Add(item+" ");
                    }
                }
                foreach (string item in olusanSifreler)
                {
                    txtVeriKaydet(Application.StartupPath + "\\ BSG Olusturulan Sifreler.txt", item);
                }
            }
        }
        public void txtVeriKaydet(String dosyaYolu,String kaydedilecekVeri) 
        {
            FileStream fs = new FileStream(dosyaYolu,FileMode.OpenOrCreate,FileAccess.Write);
            fs.Close();
            File.AppendAllText(dosyaYolu, Environment.NewLine + kaydedilecekVeri);
        }
        private void btnKarakterEkle_Click(object sender, EventArgs e)
        {
            if (txtKarakterEkle.Text != "")
            {
                if (kullanilabilecekKarakterler.Contains(txtKarakterEkle.Text))
                {
                    txtKarakterEkle.Clear();
                }
                else
                {
                    kullanilabilecekKarakterler.Add(txtKarakterEkle.Text);
                    listKullanilabilecek.Items.Add(txtKarakterEkle.Text);
                }
            }
        }
        private void txtKarakterEkle_TextChanged(object sender, EventArgs e)
        {
            if (txtKarakterEkle.Text.Length > 1)
            {
                txtKarakterEkle.Text = txtKarakterEkle.Text.Substring(0,1);
            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                tekrarEdilebilirMi = false;
            }
            else
            {
                tekrarEdilebilirMi = !tekrarEdilebilirMi;
            }
        }
        private void btnSil_Click(object sender, EventArgs e)
        {
            listKullanilabilecek.Items.Remove(listKullanilabilecek.SelectedItem);
            kullanilabilecekKarakterler.Clear();
            foreach (var item in listKullanilabilecek.Items)
            {
                kullanilabilecekKarakterler.Add(item);
            }
        }
        private void txtKarakterEkle_MouseClick_1(object sender, MouseEventArgs e)
        {
            txtKarakterEkle.Text = "";
        }
    }
}
