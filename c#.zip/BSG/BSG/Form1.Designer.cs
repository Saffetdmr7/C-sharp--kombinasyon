﻿namespace BSG
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.SifrelemeBaslat = new System.Windows.Forms.Button();
            this.txtKarakterEkle = new System.Windows.Forms.TextBox();
            this.btnKarakterEkle = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listKullanilabilecek = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lstDeneme = new System.Windows.Forms.ListBox();
            this.btnSil = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SifrelemeBaslat
            // 
            this.SifrelemeBaslat.BackColor = System.Drawing.Color.Blue;
            this.SifrelemeBaslat.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.SifrelemeBaslat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.SifrelemeBaslat.ForeColor = System.Drawing.Color.White;
            this.SifrelemeBaslat.Location = new System.Drawing.Point(290, 539);
            this.SifrelemeBaslat.Name = "SifrelemeBaslat";
            this.SifrelemeBaslat.Size = new System.Drawing.Size(206, 61);
            this.SifrelemeBaslat.TabIndex = 0;
            this.SifrelemeBaslat.Text = "Şifreleme Başlat";
            this.SifrelemeBaslat.UseVisualStyleBackColor = false;
            this.SifrelemeBaslat.Click += new System.EventHandler(this.SifrelemeBaslat_Click);
            // 
            // txtKarakterEkle
            // 
            this.txtKarakterEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtKarakterEkle.Location = new System.Drawing.Point(55, 101);
            this.txtKarakterEkle.Name = "txtKarakterEkle";
            this.txtKarakterEkle.Size = new System.Drawing.Size(168, 34);
            this.txtKarakterEkle.TabIndex = 2;
            this.txtKarakterEkle.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtKarakterEkle_MouseClick_1);
            this.txtKarakterEkle.TextChanged += new System.EventHandler(this.txtKarakterEkle_TextChanged);
            // 
            // btnKarakterEkle
            // 
            this.btnKarakterEkle.BackColor = System.Drawing.Color.Red;
            this.btnKarakterEkle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKarakterEkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKarakterEkle.Location = new System.Drawing.Point(229, 100);
            this.btnKarakterEkle.Name = "btnKarakterEkle";
            this.btnKarakterEkle.Size = new System.Drawing.Size(96, 38);
            this.btnKarakterEkle.TabIndex = 3;
            this.btnKarakterEkle.Text = "EKLE";
            this.btnKarakterEkle.UseVisualStyleBackColor = false;
            this.btnKarakterEkle.Click += new System.EventHandler(this.btnKarakterEkle_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.checkBox1.BackColor = System.Drawing.SystemColors.Control;
            this.checkBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.checkBox1.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.checkBox1.FlatAppearance.BorderSize = 4;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.Control;
            this.checkBox1.Location = new System.Drawing.Point(476, 345);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(76, 56);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.UseVisualStyleBackColor = false;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label1
            // 
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(50, 360);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 56);
            this.label1.TabIndex = 6;
            this.label1.Text = "Tekrar Kullanılabilir Mi ?";
            // 
            // listKullanilabilecek
            // 
            this.listKullanilabilecek.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listKullanilabilecek.Cursor = System.Windows.Forms.Cursors.Default;
            this.listKullanilabilecek.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.listKullanilabilecek.FormattingEnabled = true;
            this.listKullanilabilecek.ItemHeight = 25;
            this.listKullanilabilecek.Location = new System.Drawing.Point(502, 39);
            this.listKullanilabilecek.Name = "listKullanilabilecek";
            this.listKullanilabilecek.Size = new System.Drawing.Size(284, 302);
            this.listKullanilabilecek.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(50, 452);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(362, 54);
            this.label2.TabIndex = 8;
            this.label2.Text = "Kaç Elemanlı Kombinasyon Olacak?";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9"});
            this.comboBox1.Location = new System.Drawing.Point(502, 449);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(251, 33);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 9;
            // 
            // lstDeneme
            // 
            this.lstDeneme.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lstDeneme.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstDeneme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstDeneme.ForeColor = System.Drawing.Color.Red;
            this.lstDeneme.FormattingEnabled = true;
            this.lstDeneme.ItemHeight = 25;
            this.lstDeneme.Location = new System.Drawing.Point(792, 39);
            this.lstDeneme.Name = "lstDeneme";
            this.lstDeneme.Size = new System.Drawing.Size(528, 627);
            this.lstDeneme.TabIndex = 10;
            // 
            // btnSil
            // 
            this.btnSil.BackColor = System.Drawing.Color.Red;
            this.btnSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSil.Location = new System.Drawing.Point(400, 100);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(96, 38);
            this.btnSil.TabIndex = 11;
            this.btnSil.Text = "SİL";
            this.btnSil.UseVisualStyleBackColor = false;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lime;
            this.ClientSize = new System.Drawing.Size(1332, 732);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.lstDeneme);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listKullanilabilecek);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.btnKarakterEkle);
            this.Controls.Add(this.txtKarakterEkle);
            this.Controls.Add(this.SifrelemeBaslat);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SifrelemeBaslat;
        private System.Windows.Forms.TextBox txtKarakterEkle;
        private System.Windows.Forms.Button btnKarakterEkle;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.ListBox listKullanilabilecek;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ListBox lstDeneme;
        private System.Windows.Forms.Button btnSil;
    }
}

